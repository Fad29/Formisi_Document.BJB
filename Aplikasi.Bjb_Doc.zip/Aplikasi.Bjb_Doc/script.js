const form = document.getElementById('formDokumen');
const statusDiv = document.getElementById('status');

// Ganti dengan URL Web App Google Apps Script kamu:
const scriptURL = 'https://script.google.com/macros/s/AKfycbxlGQQiWiU75jMJk56LWAK4xt2UID4VLz5acFQfLL7hlwWBTcpR0qOyYYwyuMQ72gql/exec';

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const file = document.getElementById('file').files[0];
  const dummyFileUrl = file ? file.name : "file-dummy.pdf";

  const data = {
    nama: document.getElementById('nama').value,
    email: document.getElementById('email').value,
    keterangan: document.getElementById('keterangan').value,
    fileUrl: dummyFileUrl
  };

  try {
    const res = await fetch(scriptURL, {
      method: 'POST',
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    });

    const text = await res.text();
    statusDiv.innerText = '✅ Berhasil dikirim: ' + text;
    form.reset();
  } catch (err) {
    console.error(err);
    statusDiv.innerText = '❌ Gagal mengirim.';
  }
});
